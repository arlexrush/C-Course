﻿using System;

namespace Swap.Infrastructure
{
    public class Class1
    {
    }
}
