﻿using System;

namespace Swap.Domain
{
    public class Class1
    {
    }
}
